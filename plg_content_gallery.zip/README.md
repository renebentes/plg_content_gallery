Gallery - plg_content_gallery
=============

Plugin para criação de uma galeria de imagens para Joomla.

Requirements
------------

* [Joomla! 2.5+](http://www.joomla.org)

Author
------

Rene Bentes Pinto

License
--------

* This Plugin licensed under the terms of the [GNU/GPLv2](http://www.gnu.org/licenses/gpl-2.0.html) license.

Bugs/Requests
-------------

You can [report a bug or request a feature here](http://github.com/renebentes/plg_content_gallery/issues)

TODO
----



Release Notes
-------------

#####Legend:
  \+ Added \- Removed ^ Updated \* Bugfix \# Secure fix ! Relevant Message

######1.0.0

  ! Estruturação do projeto